Linux
Maven
eclipse
bower
github
--------------------
Servlet/Filter/Listener
customized taglib
Spring MVC
MyBatis
Bootstrap
AngularJS VS jQuery
angular ui
DOM or MVVM(MVW)
intro.js
---------------------
code -> API -> library -> framework -> combination
coder -> programmer -> software engineer -> architect -> master
---------------------
Frontend -> Backend -> Data Center
BDD or DDD
Java, JavaScript, V8 is built in Java 8
PHP or Java, Prototype







How to create a datepicker field

set datepicker directive for page._formControlRepository
add a new $watch to synchronize sock puppet field to true field

How to create a select field
add <so:lookup /> tag to jsp



TODO LIST
--------------------------
框架改进：
表格控件，固定表头           2015-01-05
后台前台共享验证程序
针对特定视图的校验规则定制
分页处理                   2014-12-25
LOOPUP对话框               2014-12-26
mybatis处理未知jdbcType    2014-12-28
新增文件上传组件             2015-01-08
LINKED组件静态全文检索
通用报表组件
使用嵌入式Tomcat
--------------------------
功能改进：
帮助页面                   2014-12-30
首次引导教程                2014-12-26
只读视图                   2014-12-29
Excel文件导出              2015-01-09
Excel表头设置              
点击标题刷新当前页面         2014-12-28
新增LINKED组件             2014-01-07
LOOKUP数据支持及时刷新      2014-01-12
新增富文本编辑控件           2014-01-16
表格鼠标指针
新增GZIP数据压缩传输        2014-01-20
自动加载模块对应的Phrase     2014-01-27
--------------------------
SO-FRAMEWORK内部培训      2014-01-14
--------------------------
重构：抽取pagination组件，重新规划rest路径设置，动态加载phrase，分模块加载phrase，精简JSP模块代码 2015-01-10
















[keyGenerators
 caches
 autoMappingBehavior
 defaultScriptingLanguage
 safeResultHandlerEnabled
 lazyLoadTriggerMethods
 callSettersOnNulls
 loadedResources
 objectWrapperFactory
 sqlFragments
 objectFactory
 useColumnLabel
 interceptorChain
 safeRowBoundsEnabled
 typeHandlerRegistry
 mapperRegistry
 databaseId
 incompleteStatements
 cacheRefMap
 logImpl
 useGeneratedKeys
 variables
 multipleResultSetsEnabled
 mapUnderscoreToCamelCase
 defaultStatementTimeout
 incompleteResultMaps
 typeAliasRegistry
 logPrefix
 defaultExecutorType
 incompleteMethods
 lazyLoadingEnabled
 jdbcTypeForNull
 configurationFactory
 environment
 cacheEnabled
 proxyFactory
 mappedStatements
 resultMaps
 localCacheScope
 aggressiveLazyLoading
 languageRegistry
 incompleteCacheRefs
 parameterMaps]
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
How to add a new application
----------------------------------

edit NEW_SUBAPP= in quick-subapp.sh
execute quick-subapp.sh
edit following files
http://localhost:8080/so/quick-subapp.html
DDL.sql close tomcat server -> edit open execute close
javabean
mybatis-configuration.xml
mybatis-mapper-mapper.xml
controller
jsp
js
phrase.properties
global.jsp












































CONNECT BY START WITH
GROUP BY ROLLUP/CUBE
GROUPING SETS
NULL FIRST/LAST
analytic function NULLS FIRST/LAST
PERCENT_RANK/CUME_DIST/NTILE
PIVOT
UNPIVOT

